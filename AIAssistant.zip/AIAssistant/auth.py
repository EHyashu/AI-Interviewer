from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from models import User

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.authenticate(email, password)
        if user:
            session['user_id'] = user['id']
            session['user_type'] = user['user_type']
            session['email'] = user['email']
            
            if user['user_type'] == 'company':
                return redirect(url_for('company.dashboard'))
            elif user['user_type'] == 'job_seeker':
                return redirect(url_for('job_seeker.dashboard'))
            elif user['user_type'] == 'interview_prep':
                return redirect(url_for('interview_prep.dashboard'))
        else:
            flash('Invalid email or password', 'error')
    
    return render_template('login.html')

@auth_bp.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user_type = request.form.get('user_type')
        company_name = request.form.get('company_name')
        full_name = request.form.get('full_name')
        
        user_id = User.create(email, password, user_type, company_name, full_name)
        if user_id:
            session['user_id'] = user_id
            session['user_type'] = user_type
            session['email'] = email
            
            if user_type == 'company':
                return redirect(url_for('company.dashboard'))
            elif user_type == 'job_seeker':
                return redirect(url_for('job_seeker.dashboard'))
            elif user_type == 'interview_prep':
                return redirect(url_for('interview_prep.dashboard'))
        else:
            flash('Email already exists', 'error')
    
    return render_template('signup.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))
