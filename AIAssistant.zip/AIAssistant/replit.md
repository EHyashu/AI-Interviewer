# AI Interviewer Platform

## Overview
A full-stack AI-powered interview platform built with Flask, featuring three distinct user types: Companies, Job Seekers, and Interview Practice Users. The application uses OpenAI's API to conduct intelligent interviews, filter resumes, and provide detailed feedback.

## Project Architecture

### Technology Stack
- **Backend**: Python Flask
- **Database**: SQLite
- **AI Engine**: OpenAI API (GPT-4o-mini)
- **Resume Parsing**: PyMuPDF
- **Frontend**: HTML/CSS/JavaScript (Vanilla)
- **Authentication**: Flask session-based auth with Werkzeug password hashing

### Directory Structure
```
├── app.py                 # Main Flask application
├── database.py            # Database initialization and connection
├── models.py              # Data models (User, JobDescription, Resume, InterviewSession)
├── auth.py                # Authentication routes
├── ai_engine.py           # OpenAI integration for interviews and resume filtering
├── resume_parser.py       # PDF/text resume parsing
├── routes/
│   ├── company.py         # Company dashboard and job management
│   ├── job_seeker.py      # Job seeker dashboard and interviews
│   └── interview_prep.py  # Interview practice functionality
├── templates/             # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── signup.html
│   ├── company_*.html
│   ├── job_seeker_*.html
│   ├── interview*.html
│   └── interview_prep_*.html
├── static/
│   ├── css/style.css      # Application styles
│   └── js/main.js         # Frontend JavaScript
└── uploads/               # Resume file storage
```

## Features Implemented

### 1. User Authentication
- Three user types: Company, Job Seeker, Interview Prep User
- Secure password hashing with Werkzeug
- Session-based authentication
- Role-based dashboard routing

### 2. Company Dashboard
- Post job descriptions with requirements
- Upload and parse PDF/text resumes
- AI-powered resume filtering with match scores (0-100)
- View submitted resumes with filtering status
- Track interviews conducted for each job

### 3. Job Seeker Dashboard
- Browse available job openings
- Take AI-conducted interviews for specific positions
- View interview history and scores
- Get detailed feedback on interview performance

### 4. Interview Prep Dashboard
- Practice interviews for 10 predefined roles
- Mock interview mode with AI interviewer
- Receive scoring and detailed feedback
- Track practice session history

### 5. AI Interview Engine
- Dynamic question generation based on job role
- Conversational interview flow
- Context-aware follow-up questions
- Interview evaluation with scoring (0-100)
- Detailed feedback generation

### 6. Resume Processing
- PDF parsing using PyMuPDF
- Text extraction and candidate info detection (name, email, phone)
- AI-powered resume-to-job matching
- Match score calculation

## Database Schema

### Tables
1. **users**: User accounts with type differentiation
2. **job_descriptions**: Company job postings
3. **resumes**: Uploaded resumes with match scores
4. **interview_sessions**: Interview instances with conversation history
5. **interview_questions**: Individual Q&A pairs (future use)

## Environment Variables
- `OPENAI_API_KEY`: OpenAI API key for AI functionality
- `SESSION_SECRET`: Flask session secret key

## Recent Changes
- 2025-10-08: Initial implementation of complete AI Interviewer platform
- Implemented three-tier user system with role-based dashboards
- Integrated OpenAI API for interview and resume filtering
- Created responsive UI with clean dashboard interfaces
- Set up SQLite database with complete schema

## Usage

### For Companies
1. Sign up as Company user
2. Post job descriptions
3. Upload candidate resumes (PDF/text)
4. View AI-generated match scores
5. Review interviews conducted by candidates

### For Job Seekers
1. Sign up as Job Seeker
2. Browse available positions
3. Start AI-conducted interview
4. Answer questions in chat format
5. Receive score and feedback

### For Interview Practice
1. Sign up as Interview Prep user
2. Select a role to practice
3. Take mock interview with AI
4. Get detailed performance feedback
5. Practice multiple times to improve

## API Endpoints

### Authentication
- GET/POST `/login`
- GET/POST `/signup`
- GET `/logout`

### Company Routes
- GET `/company/dashboard`
- GET/POST `/company/post-job`
- GET `/company/job/<id>`
- POST `/company/job/<id>/upload-resume`
- POST `/company/resume/<id>/update-status`

### Job Seeker Routes
- GET `/job-seeker/dashboard`
- POST `/job-seeker/interview/<job_id>/start`
- GET `/job-seeker/interview/<session_id>`
- POST `/job-seeker/interview/<session_id>/chat`
- POST `/job-seeker/interview/<session_id>/complete`
- GET `/job-seeker/interview/<session_id>/results`

### Interview Prep Routes
- GET `/interview-prep/dashboard`
- POST `/interview-prep/start`
- GET `/interview-prep/interview/<session_id>`
- POST `/interview-prep/interview/<session_id>/chat`
- POST `/interview-prep/interview/<session_id>/complete`
- GET `/interview-prep/interview/<session_id>/results`

## Future Enhancements
- Video/audio interview capability
- Advanced ML-based resume ranking
- Company admin panel for team management
- Calendar scheduling for interviews
- Email notifications
- Analytics dashboard
- Multi-language support
