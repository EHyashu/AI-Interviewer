from flask import Flask, render_template, redirect, url_for, session
from flask_cors import CORS
import os
from database import init_db

app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET', 'dev-secret-key-change-in-production')
CORS(app)

app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

from auth import auth_bp
from routes.company import company_bp
from routes.job_seeker import job_seeker_bp
from routes.interview_prep import interview_prep_bp

app.register_blueprint(auth_bp)
app.register_blueprint(company_bp, url_prefix='/company')
app.register_blueprint(job_seeker_bp, url_prefix='/job-seeker')
app.register_blueprint(interview_prep_bp, url_prefix='/interview-prep')

@app.route('/')
def index():
    if 'user_id' in session:
        user_type = session.get('user_type')
        if user_type == 'company':
            return redirect(url_for('company.dashboard'))
        elif user_type == 'job_seeker':
            return redirect(url_for('job_seeker.dashboard'))
        elif user_type == 'interview_prep':
            return redirect(url_for('interview_prep.dashboard'))
    return render_template('index.html')

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
