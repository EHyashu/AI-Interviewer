import fitz
import re

def parse_resume(file_path):
    try:
        if file_path.endswith('.pdf'):
            return parse_pdf(file_path)
        else:
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
                return text, extract_candidate_info(text)
    except Exception as e:
        print(f"Error parsing resume: {e}")
        return "", {}

def parse_pdf(file_path):
    try:
        doc = fitz.open(file_path)
        text = ""
        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            text += page.get_text()
        doc.close()
        
        candidate_info = extract_candidate_info(text)
        return text, candidate_info
    except Exception as e:
        print(f"Error parsing PDF: {e}")
        return "", {}

def extract_candidate_info(text):
    info = {}
    
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    emails = re.findall(email_pattern, text)
    if emails:
        info['email'] = emails[0]
    
    phone_pattern = r'[\+\(]?[1-9][0-9 .\-\(\)]{8,}[0-9]'
    phones = re.findall(phone_pattern, text)
    if phones:
        info['phone'] = phones[0]
    
    lines = text.split('\n')
    for line in lines[:10]:
        line = line.strip()
        if line and len(line) < 50 and not re.search(email_pattern, line) and not re.search(phone_pattern, line):
            if not any(keyword in line.lower() for keyword in ['resume', 'cv', 'curriculum', 'objective', 'summary']):
                words = line.split()
                if 2 <= len(words) <= 4 and all(word[0].isupper() for word in words if word):
                    info['name'] = line
                    break
    
    return info
