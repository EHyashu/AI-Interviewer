import os
from openai import OpenAI

client = None

def get_client():
    global client
    if client is None:
        api_key = os.environ.get('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("OPENAI_API_KEY not found in environment variables")
        client = OpenAI(api_key=api_key)
    return client

def filter_resumes(resume_text, job_description, requirements):
    try:
        cl = get_client()
        
        prompt = f"""
Analyze the following resume against the job requirements and provide a match score from 0 to 100.

Job Description: {job_description}

Requirements: {requirements}

Resume: {resume_text}

Provide only a numerical score (0-100) indicating how well the candidate matches the job requirements.
"""
        
        response = cl.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert recruiter analyzing resumes. Provide only a numerical score."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=10
        )
        
        score_text = response.choices[0].message.content.strip()
        score = float(''.join(filter(str.isdigit, score_text)))
        return min(max(score, 0), 100)
    
    except Exception as e:
        print(f"Error in filter_resumes: {e}")
        return 50.0

def conduct_interview(conversation, user_message, job_title, job_description, requirements):
    try:
        cl = get_client()
        
        system_prompt = f"""You are an AI interviewer conducting a professional interview for the position of {job_title}.

Job Description: {job_description}

Requirements: {requirements}

Your role:
1. Ask relevant, thoughtful questions about the candidate's experience, skills, and fit for the role
2. Be professional, encouraging, and conversational
3. Ask follow-up questions based on their answers
4. Cover technical skills, behavioral questions, and role-specific topics
5. After 5-7 exchanges, wrap up the interview naturally

Keep responses concise and professional. One question or comment at a time."""

        messages = [{"role": "system", "content": system_prompt}]
        
        for msg in conversation:
            messages.append(msg)
        
        if user_message:
            messages.append({"role": "user", "content": user_message})
        
        if len(conversation) == 0:
            initial_message = f"Hello! Thank you for your interest in the {job_title} position. I'm excited to learn more about you. Let's start with a simple question: Can you tell me about your background and what interests you about this role?"
            return initial_message
        
        response = cl.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.7,
            max_tokens=300
        )
        
        return response.choices[0].message.content.strip()
    
    except Exception as e:
        print(f"Error in conduct_interview: {e}")
        return "I apologize, but I'm having trouble processing your response. Could you please try again?"

def evaluate_interview(conversation, job_title, requirements):
    try:
        cl = get_client()
        
        conversation_text = "\n".join([f"{msg['role']}: {msg['content']}" for msg in conversation])
        
        prompt = f"""Evaluate this interview for the {job_title} position.

Requirements: {requirements}

Interview Transcript:
{conversation_text}

Provide:
1. A score from 0-100
2. Detailed feedback on the candidate's performance

Format your response as:
SCORE: [number]
FEEDBACK: [detailed feedback]"""

        response = cl.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert interviewer providing evaluation and feedback."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.5,
            max_tokens=500
        )
        
        result = response.choices[0].message.content.strip()
        
        score = 75.0
        feedback = result
        
        if "SCORE:" in result:
            score_line = result.split("SCORE:")[1].split("\n")[0].strip()
            score_text = ''.join(filter(str.isdigit, score_line))
            if score_text:
                score = float(score_text)
                score = min(max(score, 0), 100)
        
        if "FEEDBACK:" in result:
            feedback = result.split("FEEDBACK:")[1].strip()
        
        return score, feedback
    
    except Exception as e:
        print(f"Error in evaluate_interview: {e}")
        return 70.0, "Thank you for completing the interview. We appreciate your time and responses."

def generate_interview_questions(job_title, job_description, requirements, num_questions=5):
    try:
        cl = get_client()
        
        prompt = f"""Generate {num_questions} interview questions for a {job_title} position.

Job Description: {job_description}

Requirements: {requirements}

Provide a mix of technical, behavioral, and role-specific questions. Return only the questions, one per line."""

        response = cl.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert interviewer creating interview questions."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=500
        )
        
        questions = response.choices[0].message.content.strip().split('\n')
        return [q.strip() for q in questions if q.strip()]
    
    except Exception as e:
        print(f"Error in generate_interview_questions: {e}")
        return [
            "Tell me about your background and experience.",
            "What interests you about this role?",
            "What are your key strengths?",
            "Describe a challenging project you've worked on.",
            "Where do you see yourself in 5 years?"
        ]
