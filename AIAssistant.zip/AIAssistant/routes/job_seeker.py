from flask import Blueprint, render_template, request, redirect, url_for, session, jsonify, flash
from models import JobDescription, InterviewSession
from ai_engine import conduct_interview, evaluate_interview
import json

job_seeker_bp = Blueprint('job_seeker', __name__)

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('user_type') != 'job_seeker':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@job_seeker_bp.route('/dashboard')
@login_required
def dashboard():
    jobs = JobDescription.get_all_active()
    past_interviews = InterviewSession.get_by_user(session['user_id'])
    return render_template('job_seeker_dashboard.html', jobs=jobs, past_interviews=past_interviews)

@job_seeker_bp.route('/interview/<int:job_id>/start', methods=['POST'])
@login_required
def start_interview(job_id):
    job = JobDescription.get_by_id(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    
    session_id = InterviewSession.create(
        session['user_id'],
        job_id,
        'job_interview',
        job['title']
    )
    
    return jsonify({'session_id': session_id})

@job_seeker_bp.route('/interview/<int:session_id>')
@login_required
def interview(session_id):
    interview_session = InterviewSession.get_by_id(session_id)
    if not interview_session or interview_session['user_id'] != session['user_id']:
        flash('Interview not found', 'error')
        return redirect(url_for('job_seeker.dashboard'))
    
    job = JobDescription.get_by_id(interview_session['job_id'])
    return render_template('interview.html', session=interview_session, job=job)

@job_seeker_bp.route('/interview/<int:session_id>/chat', methods=['POST'])
@login_required
def interview_chat(session_id):
    interview_session = InterviewSession.get_by_id(session_id)
    if not interview_session or interview_session['user_id'] != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    user_message = request.json.get('message')
    conversation = json.loads(interview_session['conversation'])
    
    job = JobDescription.get_by_id(interview_session['job_id'])
    
    ai_response = conduct_interview(
        conversation,
        user_message,
        job['title'],
        job['description'],
        job['requirements']
    )
    
    conversation.append({'role': 'user', 'content': user_message})
    conversation.append({'role': 'assistant', 'content': ai_response})
    
    InterviewSession.update_conversation(session_id, conversation)
    
    return jsonify({'response': ai_response})

@job_seeker_bp.route('/interview/<int:session_id>/complete', methods=['POST'])
@login_required
def complete_interview(session_id):
    interview_session = InterviewSession.get_by_id(session_id)
    if not interview_session or interview_session['user_id'] != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    conversation = json.loads(interview_session['conversation'])
    job = JobDescription.get_by_id(interview_session['job_id'])
    
    score, feedback = evaluate_interview(conversation, job['title'], job['requirements'])
    
    InterviewSession.complete(session_id, score, feedback)
    
    return jsonify({'score': score, 'feedback': feedback})

@job_seeker_bp.route('/interview/<int:session_id>/results')
@login_required
def interview_results(session_id):
    interview_session = InterviewSession.get_by_id(session_id)
    if not interview_session or interview_session['user_id'] != session['user_id']:
        flash('Interview not found', 'error')
        return redirect(url_for('job_seeker.dashboard'))
    
    return render_template('interview_results.html', session=interview_session)
