from flask import Blueprint, render_template, request, redirect, url_for, session, jsonify, flash
from models import InterviewSession
from ai_engine import conduct_interview, evaluate_interview
import json

interview_prep_bp = Blueprint('interview_prep', __name__)

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('user_type') != 'interview_prep':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

ROLE_TEMPLATES = [
    'Software Engineer',
    'Data Scientist',
    'Product Manager',
    'Marketing Manager',
    'Sales Representative',
    'Business Analyst',
    'UI/UX Designer',
    'DevOps Engineer',
    'Full Stack Developer',
    'Customer Success Manager'
]

@interview_prep_bp.route('/dashboard')
@login_required
def dashboard():
    past_interviews = InterviewSession.get_by_user(session['user_id'])
    return render_template('interview_prep_dashboard.html', roles=ROLE_TEMPLATES, past_interviews=past_interviews)

@interview_prep_bp.route('/start', methods=['POST'])
@login_required
def start_practice():
    role_title = request.json.get('role')
    
    session_id = InterviewSession.create(
        session['user_id'],
        None,
        'mock_interview',
        role_title
    )
    
    return jsonify({'session_id': session_id})

@interview_prep_bp.route('/interview/<int:session_id>')
@login_required
def practice_interview(session_id):
    interview_session = InterviewSession.get_by_id(session_id)
    if not interview_session or interview_session['user_id'] != session['user_id']:
        flash('Interview not found', 'error')
        return redirect(url_for('interview_prep.dashboard'))
    
    return render_template('interview_prep_session.html', session=interview_session)

@interview_prep_bp.route('/interview/<int:session_id>/chat', methods=['POST'])
@login_required
def practice_chat(session_id):
    interview_session = InterviewSession.get_by_id(session_id)
    if not interview_session or interview_session['user_id'] != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    user_message = request.json.get('message')
    conversation = json.loads(interview_session['conversation'])
    
    ai_response = conduct_interview(
        conversation,
        user_message,
        interview_session['role_title'],
        f"Mock interview for {interview_session['role_title']} position",
        "General requirements for the role"
    )
    
    conversation.append({'role': 'user', 'content': user_message})
    conversation.append({'role': 'assistant', 'content': ai_response})
    
    InterviewSession.update_conversation(session_id, conversation)
    
    return jsonify({'response': ai_response})

@interview_prep_bp.route('/interview/<int:session_id>/complete', methods=['POST'])
@login_required
def complete_practice(session_id):
    interview_session = InterviewSession.get_by_id(session_id)
    if not interview_session or interview_session['user_id'] != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    conversation = json.loads(interview_session['conversation'])
    
    score, feedback = evaluate_interview(
        conversation,
        interview_session['role_title'],
        "General requirements"
    )
    
    InterviewSession.complete(session_id, score, feedback)
    
    return jsonify({'score': score, 'feedback': feedback})

@interview_prep_bp.route('/interview/<int:session_id>/results')
@login_required
def practice_results(session_id):
    interview_session = InterviewSession.get_by_id(session_id)
    if not interview_session or interview_session['user_id'] != session['user_id']:
        flash('Interview not found', 'error')
        return redirect(url_for('interview_prep.dashboard'))
    
    return render_template('interview_prep_results.html', session=interview_session)
