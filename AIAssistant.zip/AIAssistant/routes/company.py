from flask import Blueprint, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.utils import secure_filename
from models import JobDescription, Resume, InterviewSession
from ai_engine import filter_resumes
from resume_parser import parse_resume
import os

company_bp = Blueprint('company', __name__)

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('user_type') != 'company':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@company_bp.route('/dashboard')
@login_required
def dashboard():
    jobs = JobDescription.get_by_company(session['user_id'])
    return render_template('company_dashboard.html', jobs=jobs)

@company_bp.route('/post-job', methods=['GET', 'POST'])
@login_required
def post_job():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        requirements = request.form.get('requirements')
        
        job_id = JobDescription.create(session['user_id'], title, description, requirements)
        flash('Job posted successfully!', 'success')
        return redirect(url_for('company.dashboard'))
    
    return render_template('company_post_job.html')

@company_bp.route('/job/<int:job_id>')
@login_required
def view_job(job_id):
    job = JobDescription.get_by_id(job_id)
    if not job or job['company_id'] != session['user_id']:
        flash('Job not found', 'error')
        return redirect(url_for('company.dashboard'))
    
    resumes = Resume.get_by_job(job_id)
    interviews = InterviewSession.get_by_job(job_id)
    return render_template('company_job_detail.html', job=job, resumes=resumes, interviews=interviews)

@company_bp.route('/job/<int:job_id>/upload-resume', methods=['POST'])
@login_required
def upload_resume(job_id):
    job = JobDescription.get_by_id(job_id)
    if not job or job['company_id'] != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if 'resume' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['resume']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if file:
        filename = secure_filename(file.filename)
        file_path = os.path.join('uploads', f"{job_id}_{filename}")
        file.save(file_path)
        
        resume_text, candidate_info = parse_resume(file_path)
        
        match_score = filter_resumes(resume_text, job['description'], job['requirements'])
        
        resume_id = Resume.create(
            job_id,
            candidate_info.get('name', 'Unknown'),
            candidate_info.get('email', ''),
            candidate_info.get('phone', ''),
            resume_text,
            file_path,
            match_score
        )
        
        return jsonify({
            'success': True,
            'resume_id': resume_id,
            'match_score': match_score
        })
    
    return jsonify({'error': 'File upload failed'}), 500

@company_bp.route('/resume/<int:resume_id>/update-status', methods=['POST'])
@login_required
def update_resume_status(resume_id):
    status = request.json.get('status')
    Resume.update_status(resume_id, status)
    return jsonify({'success': True})
