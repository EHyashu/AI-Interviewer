console.log('AI Interviewer loaded');
