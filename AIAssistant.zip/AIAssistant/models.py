from database import get_db
from werkzeug.security import generate_password_hash, check_password_hash
import json
from datetime import datetime
import sqlite3

class User:
    @staticmethod
    def create(email, password, user_type, company_name=None, full_name=None):
        conn = get_db()
        cursor = conn.cursor()
        hashed_password = generate_password_hash(password)
        try:
            cursor.execute('''
                INSERT INTO users (email, password, user_type, company_name, full_name)
                VALUES (?, ?, ?, ?, ?)
            ''', (email, hashed_password, user_type, company_name, full_name))
            conn.commit()
            user_id = cursor.lastrowid
            conn.close()
            return user_id
        except sqlite3.IntegrityError:
            conn.close()
            return None
    
    @staticmethod
    def authenticate(email, password):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            return dict(user)
        return None
    
    @staticmethod
    def get_by_id(user_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user = cursor.fetchone()
        conn.close()
        return dict(user) if user else None

class JobDescription:
    @staticmethod
    def create(company_id, title, description, requirements):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO job_descriptions (company_id, title, description, requirements)
            VALUES (?, ?, ?, ?)
        ''', (company_id, title, description, requirements))
        conn.commit()
        job_id = cursor.lastrowid
        conn.close()
        return job_id
    
    @staticmethod
    def get_by_company(company_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM job_descriptions 
            WHERE company_id = ? 
            ORDER BY created_at DESC
        ''', (company_id,))
        jobs = cursor.fetchall()
        conn.close()
        return [dict(job) for job in jobs]
    
    @staticmethod
    def get_all_active():
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT jd.*, u.company_name 
            FROM job_descriptions jd
            JOIN users u ON jd.company_id = u.id
            ORDER BY jd.created_at DESC
        ''')
        jobs = cursor.fetchall()
        conn.close()
        return [dict(job) for job in jobs]
    
    @staticmethod
    def get_by_id(job_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM job_descriptions WHERE id = ?', (job_id,))
        job = cursor.fetchone()
        conn.close()
        return dict(job) if job else None

class Resume:
    @staticmethod
    def create(job_id, candidate_name, email, phone, resume_text, file_path, match_score):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO resumes (job_id, candidate_name, email, phone, resume_text, file_path, match_score)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (job_id, candidate_name, email, phone, resume_text, file_path, match_score))
        conn.commit()
        resume_id = cursor.lastrowid
        conn.close()
        return resume_id
    
    @staticmethod
    def get_by_job(job_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM resumes 
            WHERE job_id = ? 
            ORDER BY match_score DESC, uploaded_at DESC
        ''', (job_id,))
        resumes = cursor.fetchall()
        conn.close()
        return [dict(resume) for resume in resumes]
    
    @staticmethod
    def update_status(resume_id, status):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('UPDATE resumes SET status = ? WHERE id = ?', (status, resume_id))
        conn.commit()
        conn.close()

class InterviewSession:
    @staticmethod
    def create(user_id, job_id, interview_type, role_title):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO interview_sessions (user_id, job_id, interview_type, role_title, conversation)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, job_id, interview_type, role_title, '[]'))
        conn.commit()
        session_id = cursor.lastrowid
        conn.close()
        return session_id
    
    @staticmethod
    def get_by_id(session_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM interview_sessions WHERE id = ?', (session_id,))
        session = cursor.fetchone()
        conn.close()
        return dict(session) if session else None
    
    @staticmethod
    def update_conversation(session_id, conversation):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE interview_sessions 
            SET conversation = ? 
            WHERE id = ?
        ''', (json.dumps(conversation), session_id))
        conn.commit()
        conn.close()
    
    @staticmethod
    def complete(session_id, score, feedback):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE interview_sessions 
            SET score = ?, feedback = ?, status = 'completed', completed_at = ?
            WHERE id = ?
        ''', (score, feedback, datetime.now(), session_id))
        conn.commit()
        conn.close()
    
    @staticmethod
    def get_by_user(user_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM interview_sessions 
            WHERE user_id = ? 
            ORDER BY created_at DESC
        ''', (user_id,))
        sessions = cursor.fetchall()
        conn.close()
        return [dict(session) for session in sessions]
    
    @staticmethod
    def get_by_job(job_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT iss.*, u.email, u.full_name 
            FROM interview_sessions iss
            LEFT JOIN users u ON iss.user_id = u.id
            WHERE iss.job_id = ? 
            ORDER BY iss.created_at DESC
        ''', (job_id,))
        sessions = cursor.fetchall()
        conn.close()
        return [dict(session) for session in sessions]
